# Scratch card 

A Pen created on CodePen.

Original URL: [https://codepen.io/Peaceful-World/pen/VYwYbxe](https://codepen.io/Peaceful-World/pen/VYwYbxe).

